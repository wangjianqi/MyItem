//
//  AppDelegate.h
//  Attend
//
//  Created by QianFeng on 16/5/11.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate,RESideMenuDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

