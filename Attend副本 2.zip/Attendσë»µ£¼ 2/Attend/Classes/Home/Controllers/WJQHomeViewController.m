//
//  WJQHomeViewController.m
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQHomeViewController.h"
#import "WJQViewController.h"
#import "WJQTableViewController.h"
#import "WJQCollectionViewController.h"

@interface WJQHomeViewController ()

@property (nonatomic ,strong) NSArray *styles;

@end

@implementation WJQHomeViewController
- (instancetype)init {
    if (self = [super init]) {
        self.menuHeight = 40.0;
        self.menuViewStyle = WMMenuViewStyleLine;
        self.menuItemWidth = 100;
    }
    return self;
}

- (NSArray *)titles {
    return @[@"社会热点", @"食品新闻", @"疾病快讯",@"药品新闻",@"生活贴士",@"医疗新闻",@"企业要闻"];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"首页";
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Left"
                                                                             style:UIBarButtonItemStylePlain
                                                                            target:self
                                                                            action:@selector(presentLeftMenuViewController:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Right"
                                                                              style:UIBarButtonItemStylePlain
                                                                             target:self
                                                                             action:@selector(presentRightMenuViewController:)];
    
    [self addViews];
}

- (void)addViews {
    UIButton *rightView = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, self.menuHeight)];
    [rightView setTitle:@"添加" forState:UIControlStateNormal];
    [rightView setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [rightView addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    self.menuView.rightView = rightView;
}
- (void)buttonPressed:(UIButton *)btn{
    NSLog(@"点击了按钮");
}

- (NSInteger)numbersOfChildControllersInPageController:(WMPageController *)pageController {
    return self.titles.count;
}

- (UIViewController *)pageController:(WMPageController *)pageController viewControllerAtIndex:(NSInteger)index {
    switch (index) {
        case 0: {
            WJQViewController *vc = [[WJQViewController alloc] init];
            return vc;
        }
            break;
        case 1: {
            WJQTableViewController *vc = [[WJQTableViewController alloc] initWithStyle:UITableViewStylePlain];
            return vc;
        }
            break;
        case 2: {
            WJQTwoTableViewController *vc = [[WJQTwoTableViewController alloc] init];
            return vc;
        }
            break;
        case 3: {
            WJQThreeTableViewController *vc = [[WJQThreeTableViewController alloc] init];
            return vc;
        }
            break;
        case 4: {
            WJQFourTableViewController *vc = [[WJQFourTableViewController alloc] init];
            return vc;
        }
            break;
        case 5: {
            WJQViewController *vc = [[WJQViewController alloc] init];
            return vc;
        }
            break;
        default:
        
        {
            return [[WJQCollectionViewController alloc] init];
        }
            break;
    }
    
}

- (NSString *)pageController:(WMPageController *)pageController titleAtIndex:(NSInteger)index {
    return self.titles[index];
}

//- (void)pageController:(WMPageController *)pageController lazyLoadViewController:(__kindof UIViewController *)viewController withInfo:(NSDictionary *)info {
//    NSLog(@"%@", info);
//}

//- (void)pageController:(WMPageController *)pageController willEnterViewController:(__kindof UIViewController *)viewController withInfo:(NSDictionary *)info {
//    NSLog(@"%@", info);
//}
@end
