
//
//  WJQTableViewController.m
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQTableViewController.h"
#import "WMLoopView.h"

@interface WJQTableViewController ()<WMLoopViewDelegate>
{
    int _page;
}

@property (nonatomic,strong) NSMutableArray *dataArray;

@end
@implementation WJQTableViewController
//懒加载
- (NSMutableArray *)dataArray{
    if (_dataArray == nil) {
        _dataArray = [[NSMutableArray alloc]init];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.showsVerticalScrollIndicator = NO;
    
    NSArray *images = @[@"Me_head@3x",@"Me_head@3x",@"Me_head@3x"];
    WMLoopView *loopView = [[WMLoopView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.width/1.8) images:images autoPlay:YES delay:10.0];
    loopView.delegate = self;
    self.tableView.tableHeaderView = loopView;
    self.tableView.rowHeight = 80;
    
    UINib *nib = [UINib nibWithNibName:@"WJQHomeCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"WJQHomeCell"];
    self.tableView.estimatedRowHeight = 100;

    [self addRefresh];
    [self getNewData];
    [self.tableView.mj_header beginRefreshing];

}
-(void)addRefresh{
    //添加下拉刷新
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(getNewData)];
    //添加上拉加载更多
    self.tableView.mj_footer = [MJRefreshBackFooter footerWithRefreshingTarget:self refreshingAction:@selector(getMoreData)];
}
-(void)getNewData{
    _page = 1;
    [self getData:_page];
}
-(void)getMoreData{
    _page ++;
    [self getData:_page];
}



- (void)getData:(int)page{
    NSString *httpUrl = @"http://apis.baidu.com/tngou/info/list";
    NSString *httpArg = [NSString stringWithFormat:@"id=0&page=%d&rows=20",_page];
    [self request: httpUrl withHttpArg: httpArg];

}
-(void)request: (NSString*)httpUrl withHttpArg: (NSString*)HttpArg  {
    NSString *urlStr = [[NSString alloc]initWithFormat: @"%@?%@", httpUrl, HttpArg];
    NSURL *url = [NSURL URLWithString: urlStr];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"GET"];
    [request addValue: @"e6f5cc7c0efe9c66536c6cede8de39e4" forHTTPHeaderField: @"apikey"];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               if (error) {
                                   [MBProgressHUD showError:[NSString stringWithFormat:@"%@%ld",error.localizedDescription,error.code]];
                               } else {
                                   //在这里解析
                                   NSDictionary * dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                                   
                                   NSArray *array = dict[@"tngou"];
                                   if (_page == 1) {
                                       [self.dataArray removeAllObjects];
                                   }
                                   self.dataArray = [WJQHomePageModel arrayOfModelsFromDictionaries:array];
                                   NSLog(@"%@",self.dataArray);
                                   [self.tableView reloadData];
                                   [self.tableView.mj_header endRefreshing];
                                   [self.tableView.mj_footer endRefreshing];

                                }
                           }];
}


#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WJQHomeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"WJQHomeCell"];
    cell.model = self.dataArray[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 300;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleNone;
}




//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    WMSecondViewController *vc = [[WMSecondViewController alloc] init];
//    vc.pageController = (WMPageController *)self.parentViewController;
//    [self.navigationController pushViewController:vc animated:YES];
//}

//- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (indexPath.row % 2 == 0) {
//        return YES;
//    }
//    return NO;
//}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

- (void)dealloc {
    NSLog(@"%@ destroyed",[self class]);
}



@end
