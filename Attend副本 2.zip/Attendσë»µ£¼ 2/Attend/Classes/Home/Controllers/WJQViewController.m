//
//  WJQViewController.m
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQViewController.h"

@interface WJQViewController ()

@end

@implementation WJQViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

@end
