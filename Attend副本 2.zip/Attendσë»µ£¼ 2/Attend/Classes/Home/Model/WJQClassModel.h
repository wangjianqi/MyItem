//
//  WJQClassModel.h
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "JSONModel.h"

@interface WJQClassModel : JSONModel


@property (nonatomic,assign) NSInteger id;

@property (nonatomic,copy)NSString * name;

@property (nonatomic,copy)NSString * title;

@property (nonatomic,copy)NSString * keywords;

@property (nonatomic,copy)NSString * descriptionTitle;

//排序 从0。。。。10开始
@property (nonatomic,assign) NSInteger seq;

@end
