//
//  WJQHomePageModel.h
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "JSONModel.h"
//资讯列表
@interface WJQHomePageModel : JSONModel
/**
 *  资讯标题
 */
@property (nonatomic,copy) NSString *title;

@property (nonatomic,copy)NSString * descriptionTitle;

@property (nonatomic,copy)NSString * keywords;
/**
 *  图片
 */
@property (nonatomic,copy)NSString * img;
/**
 *  发布时间
 */
@property (nonatomic,assign) NSInteger time;
/**
 *  访问次数
 */
@property (nonatomic,assign) NSInteger count;
/**
 *  评论次数
 */
@property (nonatomic,assign) NSInteger rcount;

/**
 *  收藏次数
 */
@property (nonatomic,assign) NSInteger fcount;


@property (nonatomic,assign) NSInteger id;




@end
