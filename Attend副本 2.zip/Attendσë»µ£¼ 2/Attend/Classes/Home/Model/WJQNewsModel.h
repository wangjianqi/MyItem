//
//  WJQNewsModel.h
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "JSONModel.h"

@interface WJQNewsModel : JSONModel

@property (nonatomic,copy)NSString *  title;//资讯标题
@property (nonatomic,assign)NSInteger infoclass;//分类
@property (nonatomic,copy)NSString *  img;//图片  http://tnfs.tngou.net/image
@property (nonatomic,copy)NSString *  descriptionTitle;//描述
@property (nonatomic,copy)NSString *  keywords;//关键字
@property (nonatomic,copy)NSString *  message;//资讯内容
@property (nonatomic,assign)NSInteger count ;//访问次数
@property (nonatomic,assign)NSInteger fcount;//收藏数
@property (nonatomic,assign)NSInteger rcount;//评论读数
@property (nonatomic,assign)NSInteger time;


@end
