//
//  WJQHomeCell.h
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WJQHomeCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *iconImageVIew;
@property (weak, nonatomic) IBOutlet UILabel *keywordLabel;

@property (nonatomic,strong) WJQHomePageModel *model;

@end
