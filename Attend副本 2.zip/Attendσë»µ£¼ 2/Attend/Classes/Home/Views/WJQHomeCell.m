//
//  WJQHomeCell.m
//  Attend
//
//  Created by QianFeng on 16/5/13.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQHomeCell.h"

@implementation WJQHomeCell


- (void)setModel:(WJQHomePageModel *)model{
    _model = model;
    NSString *picUrl = [NSString stringWithFormat:@"http://tnfs.tngou.net/image%@",_model.img];
    [self.iconImageVIew sd_setImageWithURL:[NSURL URLWithString:picUrl] placeholderImage:[UIImage imageNamed:@"Picplaceholder"]];
    self.titleLabel.text = _model.title;
    self.keywordLabel.text = _model.keywords;
}

@end
