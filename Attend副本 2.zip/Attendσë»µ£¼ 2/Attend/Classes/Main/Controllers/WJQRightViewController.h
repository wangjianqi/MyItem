//
//  WJQRightViewController.h
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WJQRightViewController : UIViewController

@end
