//
//  WJQSettingViewController.m
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQSettingViewController.h"
#import "SettingView.h"
#import "TabbarButton.h"

@interface WJQSettingViewController ()<UITableViewDelegate,UITableViewDataSource,HeaderViewDelegate>

@property (nonatomic,strong) UITableView *tableView;

@property (nonatomic,strong) NSArray *titleArray;

@property (nonatomic,strong) NSArray *imagesArray;

@property (nonatomic,weak) UIView *fenxiangview;

@end

@implementation WJQSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"设置";
    self.view.backgroundColor = [UIColor colorWithRed:255/255.0 green:202/255.0 blue:101/255.0 alpha:1.0];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Left"
                                                                             style:UIBarButtonItemStylePlain
                                                                            target:self
                                                                            action:@selector(presentLeftMenuViewController:)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Right"
                                                                              style:UIBarButtonItemStylePlain
                                                                             target:self
                                                                             action:@selector(presentRightMenuViewController:)];
    
    self.titleArray = @[@"恢复提醒",@"夜间模式",@"消息推送",@"帮助和反馈",@"清除缓存",@"关于"];
    self.imagesArray = @[@"btn_aboutus",@"btn_aboutus",@"btn_aboutus",@"btn_aboutus",@"btn_aboutus",@"btn_aboutus"];
    
    [self createTableView];

}
- (void)createTableView{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 200, VIEW_WIDTH, VIEW_HEIGHT - 200) style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    SettingView *headView = [[SettingView alloc]init];
    headView.delegate = self;
//    self.tableView.tableHeaderView = headView;
}
#pragma mark - delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.titleArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString * identifier = @"cell";
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:16];
        cell.textLabel.textColor = [UIColor grayColor];
        cell.textLabel.highlightedTextColor = [UIColor lightGrayColor];
        cell.selectedBackgroundView = [[UIView alloc] init];
        
        if (indexPath.row >= 0 & indexPath.row < 3) {
            UISwitch *mySwith = [[UISwitch alloc]initWithFrame:CGRectMake(VIEW_WIDTH - 80, (cell.frame.size.height - 2*10)/2, 10, 10)];
            [cell.contentView addSubview:mySwith];
        }else{
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        
    }
    cell.textLabel.text = self.titleArray[indexPath.row];
    cell.imageView.image = [UIImage imageNamed:self.imagesArray[indexPath.row]];
    return cell;
}

#pragma mark - 登陆
- (void)LoginBtnClck:(NSString *)str
{
    if (self.fenxiangview != nil) {
        [self cancelClick];
    }
    CGFloat w = VIEW_WIDTH - 80;
    CGFloat h = 0.6 * w;
    CGFloat x = VIEW_WIDTH/2 - w/2;
    CGFloat y = VIEW_HEIGHT/2 - h/2;
    UIView *fenxiangview = [[UIView alloc]initWithFrame:CGRectMake(x,y,w,h)];
    fenxiangview.backgroundColor = [UIColor colorWithRed:246/255.0f green:246/255.0f blue:246/255.0f alpha:1];
    [self.view addSubview:fenxiangview];
    self.fenxiangview = fenxiangview;
    [fenxiangview.layer setBorderWidth:2];
    [fenxiangview.layer setBorderColor:[UIColor redColor].CGColor];
    
    UIButton *cancelB = [[UIButton alloc]init];
    cancelB.frame = CGRectMake(fenxiangview.frame.size.width - 10 - 50, 10, 50, 10);
    [cancelB setTitle:@"取消" forState:UIControlStateNormal];
    [cancelB addTarget:self action:@selector(cancelClick) forControlEvents:UIControlEventTouchUpInside];
    [cancelB setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    cancelB.titleLabel.font = [UIFont systemFontOfSize:14];
    [fenxiangview addSubview:cancelB];
    
    UIView *lineV = [[UIView alloc]init];
    lineV.backgroundColor = [UIColor grayColor];
    lineV.frame = CGRectMake(0, CGRectGetMaxY(cancelB.frame)+10, fenxiangview.frame.size.width, 1);
    [fenxiangview addSubview:lineV];
    
    NSArray *tarray = @[@"QQ",@"微信",@"微博"];
    NSArray *imageArray = @[@"登录QQ",@"登录微信",@"登录微博"];
    CGFloat hight = 80;
    CGFloat Y = (fenxiangview.frame.size.height - CGRectGetMaxY(lineV.frame))/2-10;
    for (int i = 0; i < 3; i++) {
        TabbarButton *btn = [[TabbarButton alloc]init];
        CGFloat w = (fenxiangview.frame.size.width - 40)/3;
        CGFloat x = 20+i*w;
        btn.frame = CGRectMake(x, Y, w, hight);
        [btn setTitle:tarray[i] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:15];
        [btn setImage:[UIImage imageNamed:imageArray[i]] forState:UIControlStateNormal];
        [fenxiangview addSubview:btn];
        [btn addTarget:self action:@selector(loginClick:) forControlEvents:UIControlEventTouchUpInside];
    }
}
- (void)loginClick:(UIButton *)btn
{
    NSString *title = btn.titleLabel.text;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"QQLogin" object:title];
    [self cancelClick];
}

- (void)cancelClick
{
    [self.fenxiangview removeFromSuperview];
    self.fenxiangview = nil;
}


@end
