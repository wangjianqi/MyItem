//
//  SettingView.h
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol HeaderViewDelegate <NSObject>

- (void)LoginBtnClck:(NSString *)str;

@end

@interface SettingView : UIView

@property (nonatomic,weak) UIImageView *headImage;

@property (nonatomic,weak) UILabel *nameLable;

@property (nonatomic , weak) id<HeaderViewDelegate> delegate;


@end
