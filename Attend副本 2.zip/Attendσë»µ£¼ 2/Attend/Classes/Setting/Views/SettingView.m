//
//  SettingView.m
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "SettingView.h"

@implementation SettingView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = CGRectMake(0, 0,WIDTH_UISCREEN , HEIGHT_UISCREEN * 0.6);        
        UIImageView *imageV = [[UIImageView alloc]init];
        imageV.frame = CGRectMake(self.frame.size.width/2-40, self.frame.size.height/2-40, 80, 80);
        imageV.image = [UIImage imageNamed:@""];
        [self addSubview:imageV];
        [imageV.layer setCornerRadius:40];
        imageV.clipsToBounds = YES;
        imageV.userInteractionEnabled = YES;
        self.headImage = imageV;
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(imageV.frame)+10, WIDTH_UISCREEN, 20)];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:16];
        label.text = @"立即登录";
        label.textColor = [UIColor whiteColor];
        [self addSubview:label];
        label.userInteractionEnabled = YES;
        self.nameLable = label;
        
        
        UIButton *cover = [[UIButton alloc]initWithFrame:CGRectMake(self.frame.size.width/2-40, self.frame.size.height/2-40, 80, 110)];
        [cover addTarget:self action:@selector(countLogin) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:cover];
    }
    return self;
}

#pragma mark - 登录
- (void)countLogin
{
    if ([self.nameLable.text isEqualToString:@"立即登录"]){
        if (self.delegate && [self.delegate respondsToSelector:@selector(LoginBtnClck:)]) {
            [self.delegate LoginBtnClck:@""];
        }
    }else{
        
    }
}


@end
