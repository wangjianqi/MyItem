//
//  TabbarButton.h
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>
#define tabbarButtonRatio 0.6
//默认文字得颜色， ios6 ios7
#define tabbarButtonTitleColor [UIColor blackColor]
//按钮选中文字得颜色
#define tabbarButtonTitleSelectedColor [UIColor colorWithRed:219/255.0f green:86/255.0f blue:85/255.0f alpha:1]

@interface TabbarButton : UIButton

@property (nonatomic , strong) UITabBarItem *item;

@end
