//
//  WJQDownLoadEngine.h
//  半糖
//
//  Created by QianFeng on 16/5/6.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^Success)(NSData *data);
typedef void (^Failure)(NSError *error);

@interface WJQDownLoadEngine : NSObject

+ (instancetype)shareManger;

- (void)GET:(NSString *)url params:(NSDictionary *)para success:(Success)success failure:(Failure)failure;
- (void)POST:(NSString *)url params:(NSDictionary*)para success:(Success)success failure:(Failure)failure;
@end
