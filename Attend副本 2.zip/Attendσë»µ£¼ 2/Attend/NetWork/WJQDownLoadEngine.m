//
//  WJQDownLoadEngine.m
//  半糖
//
//  Created by QianFeng on 16/5/6.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import "WJQDownLoadEngine.h"
#import "AFNetworking.h"

@interface WJQDownLoadEngine ()

@property (nonatomic,strong)AFHTTPSessionManager *manager;

@end

@implementation WJQDownLoadEngine

+ (instancetype)shareManger{
    static WJQDownLoadEngine *dle = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dle = [[WJQDownLoadEngine alloc]init];
    });
    return dle;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _manager = [AFHTTPSessionManager manager];
        _manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    }
    return self;
}

- (void)GET:(NSString *)url params:(NSDictionary *)para success:(Success)success failure:(Failure)failure{
    [_manager GET:url parameters:para success:^(NSURLSessionDataTask *task, id responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
}

- (void)POST:(NSString *)url params:(NSDictionary *)para success:(Success)success failure:(Failure)failure{
    [_manager POST:url parameters:para success:^(NSURLSessionDataTask *task, id responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        if (failure) {
            failure(error);
        }
    }];
}
@end
