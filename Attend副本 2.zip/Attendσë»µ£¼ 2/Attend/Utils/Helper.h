//
//  Helper.h
//  Attend
//
//  Created by QianFeng on 16/5/12.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Helper : NSObject


@end

@interface HPFactory : NSObject

+(UIButton *)systemButton:(CGRect)frame title:(NSString*)title target:(id)target action:(SEL)action;

@end

