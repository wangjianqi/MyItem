//
//  main.m
//  Attend
//
//  Created by QianFeng on 16/5/11.
//  Copyright © 2016年 王建旗. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
